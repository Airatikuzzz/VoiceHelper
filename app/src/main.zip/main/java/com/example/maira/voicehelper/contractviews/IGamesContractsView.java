package com.example.maira.voicehelper.contractviews;

public interface IGamesContractsView {
    void showProgress();
    void hideProgress();
    void showProgressDialog();
    void hideProgressDialog();
}
