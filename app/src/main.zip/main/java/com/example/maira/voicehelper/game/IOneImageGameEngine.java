package com.example.maira.voicehelper.game;

public interface IOneImageGameEngine extends IGameEngine {
    void onClickVoiceAnimal(String descr);
}
