package com.example.maira.voicehelper.repository;

public interface IRepository {
}
